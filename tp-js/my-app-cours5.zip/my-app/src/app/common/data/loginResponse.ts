export class LoginResponse{
    username: string | undefined;
    status : boolean | undefined;
    message: string | undefined;
    token: string | undefined;
    roles : string | undefined;
}